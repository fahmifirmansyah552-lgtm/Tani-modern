# TANI MODERN — Android / Capacitor

Project ini adalah fondasi Android yang membungkus UI TANI MODERN menjadi aplikasi native melalui Capacitor.

## Yang sudah disiapkan
- App ID: `id.tanimodern.app`
- Nama aplikasi: `TANI MODERN`
- Web layer di `www/`
- Dependensi Capacitor Android
- Camera, Geolocation, Network, Preferences untuk tahap integrasi native
- Script untuk menambah project Android, sync, open Android Studio, dan run

## Membuat project Android
Pastikan Node.js LTS dan Android Studio/Android SDK sudah terpasang.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Untuk testing:
```bash
npx cap run android
```

Untuk APK release, buka Android Studio lalu gunakan Build > Generate Signed App Bundle / APK.

## Backend produksi
Project Android ini belum berisi secret AI atau Supabase service-role key.
Secret harus tetap di server/Edge Function. Publishable Supabase key dapat dipakai di client setelah RLS dikonfigurasi.

## Target integrasi berikutnya
1. Supabase Auth
2. Database kebun/komoditas/tanaman
3. Storage foto private
4. Edge Function untuk AI Vision
5. Kamera native
6. GPS + cuaca
7. Riwayat scan
8. Jurnal/notifikasi
9. Keuangan/HPP
10. Kalender budidaya dan prediksi panen
